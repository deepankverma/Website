mapbox-studio-default-style
===========================
Default style used by new style projects in Mapbox Studio.
